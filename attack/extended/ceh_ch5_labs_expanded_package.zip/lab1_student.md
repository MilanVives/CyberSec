# Lab 1 — Password Cracking (student handout)

Objective: Crack sample password hashes using John the Ripper.
Files: shadow_sample.txt, rockyou_small.txt
See instructor solution for answers.
