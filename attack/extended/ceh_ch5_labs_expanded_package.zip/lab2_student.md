# Lab 2 — Steganography (student handout)

Objective: Find hidden messages in images using metadata inspection and file carving.
Files: stego_text_png.png, stego_appended.jpg
See instructor solution for answers.
