Cybersecurity Architecture (ACS) - Chapter 1
Lab 1: Packet Capture and Protocol Analysis with Wireshark

CONTENTS
  Lab1_Wireshark_Traffic_Analysis.pdf   The lab assignment - start here
  Lab1_Wireshark_Traffic_Analysis.md    Same content in Markdown
  chapter1_reference.pcap               Fallback capture, if you cannot capture live

DURATION       90 minutes
SUBMIT         lastname_firstname_chapter1.zip  (see "Deliverables" in the PDF)

BEFORE YOU START
  Capture only on your own machine, on traffic you generate yourself.
  Do not capture on the school network or any shared/public Wi-Fi.
  Intercepting other people's communications without consent is a criminal
  offence in Belgium (Art. 314bis Sw.) and under the EU ePrivacy Directive.

  When the lab asks you to submit a login over plain HTTP, use the dummy
  password given in the instructions. Never use a real password.

THE REFERENCE CAPTURE
  chapter1_reference.pcap is a synthetic file built for this lab - no real
  person's traffic is in it. Every display filter in the assignment works on
  it unchanged. If you use it instead of capturing live, say so in your
  report; it costs you only the "Capture setup" part of the grade.

  Open it with:  wireshark chapter1_reference.pcap

Milan Dima - milan.dima@vives.be - CC BY 4.0
